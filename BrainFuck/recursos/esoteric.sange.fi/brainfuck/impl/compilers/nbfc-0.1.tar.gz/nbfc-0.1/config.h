#define CC     "/usr/bin/gcc -g -O4"
#define JAVAC  "/usr/bin/guavac"
