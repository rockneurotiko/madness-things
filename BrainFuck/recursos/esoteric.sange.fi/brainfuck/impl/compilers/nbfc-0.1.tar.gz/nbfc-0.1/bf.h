void emmit(char * s);
extern int yyparse();
extern FILE * yyin;
